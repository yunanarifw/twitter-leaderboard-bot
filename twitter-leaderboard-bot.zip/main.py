
import os
from keep_alive import keep_alive
import requests
import json
import time
import snscrape.modules.twitter as sntwitter

# Aktifkan server Flask agar bot tetap hidup
keep_alive()

# Fungsi untuk ambil data dari snscrape
def scrape_tweets(username):
    try:
        for tweet in sntwitter.TwitterUserScraper(username).get_items():
            return {
                'likeCount': tweet.likeCount,
                'url': tweet.url
            }
    except Exception as e:
        print("Scrape error:", e)
        return None

# Fungsi untuk kirim data ke Google Apps Script
def update_to_google_sheet(username, like_count, tweet_url):
    GAS_URL = 'https://script.google.com/macros/s/AKfycbz2chsIo-HWDBy_7B4cdDxuXw9MIDveEqipGDtOC1LEDCiTS3rNiAONVNyiA-aDd7RC/exec'

    payload = {
        'username': username,
        'likes': like_count,
        'url': tweet_url
    }

    try:
        res = requests.post(GAS_URL, data=payload)
        print("Update result:", res.text)
    except Exception as e:
        print("Update failed:", e)

# Looping terus tiap 10 detik
while True:
    user = "drubthebear"  # ganti dengan username Twitter target
    tweet = scrape_tweets(user)
    if tweet:
        likes = tweet['likeCount']
        url = tweet['url']
        update_to_google_sheet(user, likes, url)
    time.sleep(10)
